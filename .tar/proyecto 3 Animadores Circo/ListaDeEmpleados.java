/**
 *Clase ListaDeEmpleados 
 *@author Alan Kevin Cano Tenorio y Malinalli Escobedo Irineo
 *@version 1.0
 */
public class ListaDeEmpleados{

        /* El nodo inical */
        private Nodo cabeza;

    
        //este no se ocupa verdad? n0

        //CUANTO SE LE PAGARA A CADA ROL
        public double pagoRol (String rolAnimador, int cantidadContradatos ){
            double pagoRol=-1;
            Nodo aux=cabeza;
            while(aux!=null){
                if(rolAnimador.equals(aux.getTipo_empleado())){
                    pagoRol=cantidadContradatos * aux.getSueldo();
                }
            }      
            return pagoRol;
        }


        //AGREGA UN NUEVO ROL AL CATALOGO
        public void agregarEmpleadoNuevo(String rolAnimador, double sueldo){
             Nodo nuevo = new Nodo();
                    nuevo.setSiguiente(cabeza);
                    cabeza=nuevo;
                    nuevo.setCantidadEmpleado(1);
                    nuevo.setTipo_empleado(rolAnimador);
                    nuevo.setSueldo(sueldo);
        }


        // AUMENTA LA CANTIDAD DE ANIMADORES DE DETERMINADO ROL
        public boolean agregarEmpleado (String rolAnimador){
            boolean bandera=true;
            Nodo aux=cabeza;
                while (aux !=null) {
                if(aux.getTipo_empleado().equals(rolAnimador)){
                        aux.setCantidadEmpleado(aux.getCantidadEmpleado()+1);
                        bandera=false;
                    }
                    aux=aux.getSiguiente();
                }
            return bandera;
        }


     
        //ELIMINA A UN ANIMADOR
        public void eliminarEmpleado (String tipoEmpleado){
            Nodo anterior = cabeza;
            Nodo actual = cabeza.getSiguiente();
            if(tipoEmpleado.equals(cabeza.getTipo_empleado())){
                 if(cabeza.getCantidadEmpleado()==1){
                        cabeza = cabeza.getSiguiente();
                    }else{
                    cabeza.setCantidadEmpleado(cabeza.getCantidadEmpleado()-1);
                    }
            }
            while(actual != null){
                 if(tipoEmpleado.equals(actual.getTipo_empleado())){
                    if(actual.getCantidadEmpleado()==1){
                        anterior.setSiguiente(actual.getSiguiente());
                    }else{
                    actual.setCantidadEmpleado(actual.getCantidadEmpleado()-1);
                    }
                 }
                anterior = actual;
                actual = actual.getSiguiente();
            }
        }


          //MODIFICA EL NOMBRE DEL ROL
         public void mRol(String rolAnimador, String nuevoRol){
            Nodo aux=cabeza;
            while(aux!=null){
                if(rolAnimador.equals(aux.getTipo_empleado())){
                    aux.setTipo_empleado(nuevoRol);
                }
                 aux = aux.getSiguiente(); 
            }
        }

        //MODIFICA EL SUELDO DE UN ROL DE ANIMADORES
        public void mSueldo(String rolAnimador, double nuevoSueldo){
            Nodo aux=cabeza;
            while(aux!=null){
                if(rolAnimador.equals(aux.getTipo_empleado())){
                    aux.setSueldo(nuevoSueldo);
                }
                aux = aux.getSiguiente(); 
            }
        }

      

        //HACE LA COTIZACION
    public double cotizacion(String tipoEmpleado, int cantidadEmpleados, int horasEvento, double comision, ListaDeEmpleados cotizacion) {
        Nodo aux = cabeza;
        double totalPago = 0;
    
        while (aux != null) {
            if (tipoEmpleado.equals(aux.getTipo_empleado())) {
                if (cantidadEmpleados <= aux.getCantidadEmpleado()) {
                    totalPago += aux.getSueldo() * cantidadEmpleados * horasEvento;
                    

                } else {
                    System.out.println("No hay suficientes " + tipoEmpleado + " en el catálogo.");
                }
            }
            aux = aux.getSiguiente();
        }
    
        return totalPago + (totalPago * comision / 100);
    }




    //VERIFICA EN LA LISTA SI UN EMPLEADO ESTA EN ESA LISTA
        public boolean contiene(String elemento){
            Nodo aux = cabeza;
            while(aux != null){
                if(aux.getTipo_empleado().equals(elemento)){
            return true;
                }
                 aux=aux.getSiguiente();
            }
            return false;
        }
    




        //OBTIENE EL SUELDO POR HORA
        public double sueldoPorHora (String rolAnimador){
            Nodo aux=cabeza;
            double sueldo=0;
            while(aux!=null){
                if(rolAnimador.equals(aux.getTipo_empleado())){
                    sueldo = aux.getSueldo();
                }
                 aux = aux.getSiguiente(); 
            }
            return sueldo;
        }

         public int Cantidad(String rolAnimador){
            Nodo aux=cabeza;
            int cantidadPrincipal=0;
            while(aux!=null){
                if(rolAnimador.equals(aux.getTipo_empleado())){
                    cantidadPrincipal = aux.getCantidadEmpleado();
                }
                 aux = aux.getSiguiente(); 
            }
            return cantidadPrincipal;
        }

        //mODIFICA LOS VALORES DEL EMPLEADO
        public boolean modificar(String rolAnimador, int cantidad, double sueldoPorHora, int horas, ListaDeEmpleados cotizacion, int cantidadPrincipal){
            if(!cotizacion.contiene(rolAnimador)){
                    cotizacion.agregarEmpleadoNuevo(rolAnimador, sueldoPorHora);
                    Nodo aux=cabeza;
                    while(aux!=null){
                        if(rolAnimador.equals(aux.getTipo_empleado())){
                            aux.setCantidadEmpleado(cantidad);
                            if(aux.getCantidadEmpleado()> cantidadPrincipal){
                            return false;
                        }
                        }

                        aux = aux.getSiguiente(); 
                        
                    }
            }else{  
                 Nodo auxi=cabeza;
                while(auxi!=null){
                    if(rolAnimador.equals(auxi.getTipo_empleado())){
                        auxi.setCantidadEmpleado(auxi.getCantidadEmpleado()+cantidad);
                        if(auxi.getCantidadEmpleado()> cantidadPrincipal){
                            return false;
                        }
                    }
                    auxi = auxi.getSiguiente(); 
                }
                
            }
            return true;
            
        }


    /**
    * Indica si la lista es vacia
    * @return true si la lista es vacia, false en otro caso
    */
    public boolean esVacia(){
    //Aqui va tu codigo
    return cabeza == null;
    }
    
 


    //MUESTRA LAS LISTAS
    public void muestra() {
        if(esVacia())
        System.out.println("No tienes trabajadores contratados");
        else {
            Nodo aux = cabeza;
            while (aux != null) {
                System.out.println("Tipo de empleado: "+aux.getTipo_empleado() + " Cantidad: " + aux.getCantidadEmpleado() + " Sueldo por hora: $" + aux.getSueldo() + "\n");
                aux = aux.getSiguiente(); 
            }
        }
    }
    

    //LIMPIA LAS LISTAS
    public void limpia(){        
        cabeza = null;
        }
        
     


      

}
